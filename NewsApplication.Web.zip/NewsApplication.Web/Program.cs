using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NewsApplication.Repository;              // AddInfrastructure(...)
using NewsApplication.Repository.Config;
using NewsApplication.Service;                // AddApplication(...)
using NewsApplication.Service.Interfaces;     // IArticleReadService
using NewsApplication.Web.Stubs;             // FakeArticleReadService, FakeGeoService

var builder = WebApplication.CreateBuilder(args);

// 1) MVC
builder.Services.AddControllersWithViews();

// 2) Stubs you actually use in controllers (keep geo so /api/reverse works)
builder.Services.AddSingleton<IFakeGeoService, FakeGeoService>();

// 3) Choose the article implementation used by controllers
//    We want the FAKE for your dev/demo scenario.
// !!!!!!!!!    THE FAKE ARTICLE SERVICE     !!!!!!!!!
builder.Services.AddScoped<IArticleReadService, FakeArticleReadService>();

// 4) Application layer (options, clock, memory cache, decorator)
//    IMPORTANT: call ONCE and AFTER registering the fake so the decorator wraps it.

// 5) Infrastructure (DbContext, repos, HttpClients, etc.)

// 6) (Dev only) CORS if you run a separate Vite app
builder.Services.AddCors(opts =>
{
    opts.AddPolicy("DevCors", p => p
        .WithOrigins("http://localhost:5173")
        .AllowAnyHeader()
        .AllowAnyMethod());
});



builder.Services.AddNewsRepositories(builder.Configuration);
builder.Services.AddNewsServiceLayer(builder.Configuration);
var app = builder.Build();

// 7) Error handling & dev CORS
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    app.UseCors("DevCors");
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

app.MapControllers();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
