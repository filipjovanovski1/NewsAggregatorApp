﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using NewsApplication.Web.Models;         // <-- Web DTOs: SearchResultDto, ReverseResultDto
using NewsApplication.Web.Stubs;

namespace NewsApplication.Web.Controllers;

[ApiController]
[Route("api")]
public class SearchController : ControllerBase
{
    private readonly IFakeGeoService _geo;
    public SearchController(IFakeGeoService geo) => _geo = geo;

    [HttpGet("search")]
    public ActionResult<IEnumerable<SearchResultDto>> Search([FromQuery] string q)
    {
        if (string.IsNullOrWhiteSpace(q)) return Ok(Array.Empty<SearchResultDto>());
        return Ok(_geo.Search(q));
    }

    [HttpGet("reverse")]
    public ActionResult<ReverseResultDto?> Reverse([FromQuery] double lat, [FromQuery] double lng)
        => Ok(_geo.Reverse(lat, lng));
}



//CURRENT IMPLEMENTATION, STUB IS WRITTEN ABOVE


//using Microsoft.AspNetCore.Mvc;
//using NewsApplication.Service.Dtos;
//using NewsApplication.Service.Interfaces;
//using System.Globalization;

//namespace NewsApplication.Web.Controllers;

//[ApiController]
//[Route("api/search")]
//public sealed class SearchController : ControllerBase
//{
//    private readonly IReferenceDataService _reference;

//    public SearchController(IReferenceDataService reference) => _reference = reference;

//    // GET /api/search/cities?q=skopje&take=10
//    [HttpGet("cities")]
//    public async Task<ActionResult<IReadOnlyList<CityDto>>> SearchCities([FromQuery] string q, [FromQuery] int take = 20)
//    {
//        if (string.IsNullOrWhiteSpace(q)) return BadRequest("q is required");
//        var cities = await _reference.SearchCitiesAsync(q, take);
//        return Ok(cities);
//    }

//    // GET /api/search/countries?q=macedonia
//    [HttpGet("countries")]
//    public async Task<ActionResult<IReadOnlyList<CountryDto>>> SearchCountries([FromQuery] string q)
//    {
//        if (string.IsNullOrWhiteSpace(q)) return BadRequest("q is required");
//        var all = await _reference.ListCountriesAsync();
//        var qNorm = q.Trim();
//        var results = all
//            .Where(c =>
//                c.Iso2.Equals(qNorm, StringComparison.OrdinalIgnoreCase) ||
//                c.Name.Contains(qNorm, StringComparison.OrdinalIgnoreCase))
//            .ToList()
//            .AsReadOnly();
//        return Ok(results);
//    }

//    public sealed record CombinedSearchResult(
//        IReadOnlyList<CountryDto> Countries,
//        IReadOnlyList<CityDto> Cities
//    );

//    // GET /api/search?q=skop
//    [HttpGet]
//    public async Task<ActionResult<CombinedSearchResult>> Combined([FromQuery] string q, [FromQuery] int take = 10)
//    {
//        if (string.IsNullOrWhiteSpace(q)) return BadRequest("q is required");

//        var countriesTask = _reference.ListCountriesAsync();
//        var citiesTask = _reference.SearchCitiesAsync(q, take);

//        var countriesAll = await countriesTask;
//        var countries = countriesAll
//            .Where(c =>
//                c.Iso2.Equals(q, StringComparison.OrdinalIgnoreCase) ||
//                c.Name.Contains(q, StringComparison.OrdinalIgnoreCase))
//            .ToList()
//            .AsReadOnly();

//        var cities = await citiesTask;

//        return Ok(new CombinedSearchResult(countries, cities));
//    }
//}
