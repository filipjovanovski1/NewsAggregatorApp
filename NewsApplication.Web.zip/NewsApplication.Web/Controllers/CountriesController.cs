﻿using Microsoft.AspNetCore.Mvc;
using NewsApplication.Service.Dtos;
using NewsApplication.Service.Interfaces;

namespace NewsApplication.Web.Controllers;

[ApiController]
[Route("api/countries")]
public class CountriesController : ControllerBase
{
    private readonly IArticleReadService _articles;
    public CountriesController(IArticleReadService articles) => _articles = articles;

    // GET /api/countries/MK/articles?page=1&pageSize=6&take=23&category=tech
    [HttpGet("{iso2:alpha:length(2)}/articles")]
    public async Task<ActionResult<PagedResult<ArticleDto>>> GetArticles(
        [FromRoute] string iso2,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 6,
        [FromQuery] int? take = null,
        [FromQuery] string? category = null,
        CancellationToken ct = default)
    {
        try
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 6;

            iso2 = iso2.ToUpperInvariant();

            // Your fake returns a LIST up to "take". We page that list here.
            var window = Math.Max(take ?? (page * pageSize), pageSize);
            var list = await _articles.GetByLocationAsync(iso2, cityId: null, take: window, category: category, cancellationToken: ct);

            var items = list
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            var result = new PagedResult<ArticleDto>
            {
                Items = items,
                Total = list.Count, // total within the taken window
                Page = page,
                PageSize = pageSize
            };

            return Ok(result);
        }
        catch (Exception ex)
        {
            return Problem(title: "Country article fetch failed", detail: ex.Message, statusCode: 500);
        }
    }
}
