﻿using Microsoft.AspNetCore.Mvc;
using NewsApplication.Service.Dtos;
using NewsApplication.Service.Interfaces;

namespace NewsApplication.Web.Controllers;

[ApiController]
[Route("api/world")]
public class WorldController : ControllerBase
{
    private readonly IArticleReadService _articles;
    public WorldController(IArticleReadService articles) => _articles = articles;

    // GET /api/world/articles?page=1&pageSize=6&take=23&category=business
    [HttpGet("articles")]
    public async Task<ActionResult<PagedResult<ArticleDto>>> GetArticles(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 6,
        [FromQuery] int? take = null,
        [FromQuery] string? category = null,
        CancellationToken ct = default)
    {
        try
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 6;

            var window = Math.Max(take ?? (page * pageSize), pageSize);
            var list = await _articles.GetTopWorldAsync(window, category, ct);

            var items = list
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            var result = new PagedResult<ArticleDto>
            {
                Items = items,
                Total = list.Count, // total within the taken window
                Page = page,
                PageSize = pageSize
            };

            return Ok(result);
        }
        catch (Exception ex)
        {
            return Problem(title: "TopWorld fetch failed", detail: ex.Message, statusCode: 500);
        }
    }
}
