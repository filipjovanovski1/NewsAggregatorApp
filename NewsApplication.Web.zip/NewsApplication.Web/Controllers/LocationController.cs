﻿using Microsoft.AspNetCore.Mvc;
using NewsApplication.Service.Dtos;
using NewsApplication.Service.Interfaces;

namespace NewsApplication.Web.Controllers;

[ApiController]
[Route("api")]
public sealed class LocationController : ControllerBase
{
    private readonly IArticleReadService _articles;

    public LocationController(IArticleReadService articles) => _articles = articles;

    // GET /api/countries/{iso2}/articles?take=30&category=General
    [HttpGet("countries/{iso2}/articles")]
    public async Task<ActionResult<IEnumerable<ArticleDto>>> ByCountry(
        string iso2, [FromQuery] int take = 30, [FromQuery] string? category = null)
    {
        var items = await _articles.GetByLocationAsync(countryIso2: iso2, cityId: null, take, category);
        return Ok(items);
    }

    // GET /api/cities/{cityId}/articles?take=30&category=General
    [HttpGet("cities/{cityId:int}/articles")]
    public async Task<ActionResult<IEnumerable<ArticleDto>>> ByCity(
        int cityId, [FromQuery] int take = 30, [FromQuery] string? category = null)
    {
        var items = await _articles.GetByLocationAsync(countryIso2: null, cityId, take, category);
        return Ok(items);
    }
}
