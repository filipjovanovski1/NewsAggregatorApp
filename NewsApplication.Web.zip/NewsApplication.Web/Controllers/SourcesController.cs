﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NewsApplication.Service.Dtos;
using NewsApplication.Service.Interfaces;

namespace NewsApplication.Web.Controllers
{
    [ApiController]
    [Route("api/sources")]
    public sealed class SourcesController : ControllerBase
    {
        private readonly IReferenceDataService _reference;

        public SourcesController(IReferenceDataService reference)
            => _reference = reference;

        // GET /api/sources?countryIso2=US
        // If countryIso2 is omitted/empty → returns enabled sources (global).
        [HttpGet]
        public async Task<ActionResult<IReadOnlyList<SourceDto>>> GetByCountry(
            [FromQuery] string? countryIso2,
            CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(countryIso2))
            {
                var enabled = await _reference.ListEnabledSourcesAsync(ct);
                return Ok(enabled);
            }

            var byCountry = await _reference.ListSourcesByCountryAsync(countryIso2, ct);
            return Ok(byCountry);
        }

        // GET /api/sources/enabled
        [HttpGet("enabled")]
        public async Task<ActionResult<IReadOnlyList<SourceDto>>> GetEnabled(CancellationToken ct)
        {
            var enabled = await _reference.ListEnabledSourcesAsync(ct);
            return Ok(enabled);
        }

        // GET /api/sources/countries/US
        [HttpGet("countries/{iso2}")]
        public async Task<ActionResult<IReadOnlyList<SourceDto>>> GetForCountry(
            string iso2,
            CancellationToken ct)
        {
            var byCountry = await _reference.ListSourcesByCountryAsync(iso2, ct);
            return Ok(byCountry);
        }
    }
}
