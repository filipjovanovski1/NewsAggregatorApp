﻿using Microsoft.AspNetCore.Mvc;
using NewsApplication.Service.Dtos;       // <-- service DTOs
using NewsApplication.Web.Stubs;

namespace NewsApplication.Web.Controllers;

[ApiController]
[Route("api/cities")]
public class CitiesController : ControllerBase
{
    private readonly IFakeArticleReadService _articles;
    public CitiesController(IFakeArticleReadService articles) => _articles = articles;

    [HttpGet("{id}/articles")]
    public ActionResult<PagedResult<ArticleDto>> GetArticles(
        [FromRoute] string id,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 30,
        [FromQuery] int? take = null,
        [FromQuery] string? category = null)
        => Ok(_articles.GetByCity(id, page, pageSize, take, category));
}
